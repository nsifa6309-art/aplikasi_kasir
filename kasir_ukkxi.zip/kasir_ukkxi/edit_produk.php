
<?php
session_start();
include "koneksi.php";
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit;
}

$id = $_GET['id'];

$query = mysqli_query($koneksi, "SELECT * FROM produk WHERE ProdukID='$id'");
$barang = mysqli_fetch_assoc($query);

if (!$barang) {
    die("Barang tidak ditemukan");
}

if (isset($_POST['update'])) {

    $nama = $_POST['nama'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    $update = mysqli_query($koneksi, "UPDATE produk SET
        NamaProduk='$nama',
        Harga='$harga',
        Stok='$stok'
        WHERE ProdukID='$id'");

    if ($update) {
        echo "<script>
            alert('Data berhasil diubah');
            window.location='produk.php';
        </script>";
        exit;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Barang</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="content">

    <div class="isi">

        <h2>Edit Barang</h2>

        <form method="POST">

            <input type="text" name="nama"
            value="<?php echo htmlspecialchars($barang['NamaProduk']); ?>"
            placeholder="Nama Barang" required>

            <input type="number" name="harga"
            value="<?php echo $barang['Harga']; ?>"
            placeholder="Harga" min="0" required>

            <input type="number" name="stok"
            value="<?php echo $barang['Stok']; ?>"
            placeholder="Stok" min="0" required>

            <button type="submit" name="update">
                Simpan Perubahan
            </button>

            <a href="produk.php">Kembali</a>

        </form>

    </div>

</div>

</body>
</html>
