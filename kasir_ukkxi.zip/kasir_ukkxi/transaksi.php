
<?php
session_start();
include "koneksi.php";

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit;
}

$pesan = "";

// Proses simpan transaksi
if (isset($_POST['simpan'])) {

    $produk_id = (int) $_POST['produk'];
    $jumlah = (int) $_POST['jumlah'];

    $cek = mysqli_query($koneksi, "SELECT * FROM produk WHERE ProdukID='$produk_id'");
    $barang = mysqli_fetch_assoc($cek);

    if (!$barang) {
        $pesan = "Barang tidak ditemukan!";
    } elseif ($jumlah <= 0) {
        $pesan = "Jumlah barang harus lebih dari 0!";
    } elseif ($jumlah > $barang['Stok']) {
        $pesan = "Stok barang tidak mencukupi!";
    } else {

        $harga = $barang['Harga'];
        $subtotal = $harga * $jumlah;
        $tanggal = date('Y-m-d');

        mysqli_begin_transaction($koneksi);

        $simpan = mysqli_query($koneksi, "INSERT INTO penjualan
        (TanggalPenjualan, TotalHarga, PelangganID)
        VALUES ('$tanggal', '$subtotal', NULL)");

        if ($simpan) {

            $id_penjualan = mysqli_insert_id($koneksi);

            $detail = mysqli_query($koneksi, "INSERT INTO detailpenjualan
            (PenjualanID, ProdukID, JumlahProduk, Subtotal)
            VALUES ('$id_penjualan', '$produk_id', '$jumlah', '$subtotal')");

            $update = mysqli_query($koneksi, "UPDATE produk
            SET Stok = Stok - $jumlah
            WHERE ProdukID = '$produk_id' AND Stok >= $jumlah");

            if ($detail && $update && mysqli_affected_rows($koneksi) == 1) {

                mysqli_commit($koneksi);

                echo "<script>
                    alert('Transaksi berhasil disimpan!');
                    window.location='laporan.php';
                </script>";
                exit;

            } else {

                mysqli_rollback($koneksi);
                $pesan = "Transaksi gagal disimpan!";
            }

        } else {

            mysqli_rollback($koneksi);
            $pesan = "Transaksi gagal!";
        }
    }
}

// Mengambil data barang
$produk = mysqli_query($koneksi, "SELECT * FROM produk WHERE Stok > 0");

?>

<!DOCTYPE html>
<html>
<head>
    <title>Transaksi Kasirku</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="sidebar">
    <h2>KASIRKU</h2>

    <a href="dashboard.php">Dashboard</a>
    <a href="produk.php">Data Barang</a>
    <a href="transaksi.php">Transaksi</a>
    <a href="laporan.php">Laporan</a>
    <a href="logout.php">Logout</a>
</div>

<div class="content">

    <h2>Transaksi Penjualan</h2>
    <p>Silakan pilih barang yang akan dibeli.</p>

    <div class="isi">

        <h3>Tambah Transaksi</h3>

        <?php if ($pesan != "") { ?>
            <p style="color:red;">
                <?php echo $pesan; ?>
            </p>
        <?php } ?>

        <form method="POST">

            <label>Nama Barang</label>

            <select name="produk" id="produk" required>
                <option value="" data-harga="0">-- Pilih Barang --</option>

                <?php while ($b = mysqli_fetch_assoc($produk)) { ?>

                    <option value="<?php echo $b['ProdukID']; ?>"
                        data-harga="<?php echo $b['Harga']; ?>">

                        <?php echo htmlspecialchars($b['NamaProduk']); ?>
                        - Rp <?php echo number_format($b['Harga'], 0, ',', '.'); ?>
                        (Stok: <?php echo $b['Stok']; ?>)

                    </option>

                <?php } ?>

            </select>

            <br><br>

            <label>Jumlah Barang</label>

            <input type="number" name="jumlah" id="jumlah"
            min="1" placeholder="Masukkan jumlah" required>

            <p>Harga: <b id="harga">Rp 0</b></p>

            <p>Total: <b id="total">Rp 0</b></p>

            <button type="submit" name="simpan">
                Simpan Transaksi
            </button>

        </form>

    </div>

</div>

<script>

var produk = document.getElementById("produk");
var jumlah = document.getElementById("jumlah");
var harga = document.getElementById("harga");
var total = document.getElementById("total");

function hitungTotal() {

    var pilihan = produk.options[produk.selectedIndex];

    var hargaBarang = Number(pilihan.getAttribute("data-harga")) || 0;
    var banyak = Number(jumlah.value) || 0;

    var totalHarga = hargaBarang * banyak;

    harga.innerHTML = "Rp " + hargaBarang.toLocaleString("id-ID");

    total.innerHTML = "Rp " + totalHarga.toLocaleString("id-ID");
}

produk.addEventListener("change", hitungTotal);

jumlah.addEventListener("input", hitungTotal);

hitungTotal();

</script>

</body>
</html>
