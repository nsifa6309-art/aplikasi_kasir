
<?php
include "koneksi.php";

if (isset($_POST['daftar'])) {

    $nama = mysqli_real_escape_string($koneksi, $_POST['nama']);
    $username = mysqli_real_escape_string($koneksi, $_POST['username']);
    $password = $_POST['password'];

    $cek = mysqli_query($koneksi, "SELECT id FROM users WHERE username='$username'");

    if (mysqli_num_rows($cek) > 0) {

        $pesan = "Username sudah digunakan!";

    } else {

        $password = password_hash($password, PASSWORD_DEFAULT);

        $simpan = mysqli_query($koneksi, "INSERT INTO users
        (nama, username, password)
        VALUES ('$nama', '$username', '$password')");

        if ($simpan) {
            header("Location: login.php");
            exit;
        } else {
            $pesan = "Register gagal!";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register Kasirku</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="form">
    <h2>REGISTER KASIRKU</h2>

    <?php if (isset($pesan)) { ?>
        <p style="color:red;"><?php echo $pesan; ?></p>
    <?php } ?>

    <form method="POST">

        <input type="text" name="nama"
        placeholder="Nama Lengkap" required>

        <input type="text" name="username"
        placeholder="Username" required>

        <input type="password" name="password"
        placeholder="Password" required>

        <button type="submit" name="daftar">DAFTAR</button>

    </form>

    <p>Sudah punya akun?</p>
    <a href="login.php">Login di sini</a>
</div>

</body>
</html>
