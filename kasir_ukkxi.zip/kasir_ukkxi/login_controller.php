<?php
session_start();
include 'koneksi.php';

if (isset($_POST['login'])) {

    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = mysqli_query($koneksi, "SELECT * FROM users WHERE username='$username'");
    $data = mysqli_fetch_assoc($query);

    if ($data) {

        if (password_verify($password, $data['password'])) {

            $_SESSION['id'] = $data['id'];
            $_SESSION['nama'] = $data['nama'];
            $_SESSION['username'] = $data['username'];

            header("Location: dashboard.php");
            exit;

        } else {
            echo "<script>
                alert('Password salah!');
                window.location='login.php';
            </script>";
        }

    } else {
        echo "<script>
            alert('Username tidak ditemukan!');
            window.location='login.php';
        </script>";
    }
}
?>