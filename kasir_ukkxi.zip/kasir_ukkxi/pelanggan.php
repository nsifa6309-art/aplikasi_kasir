
<?php
include "koneksi.php";

if (isset($_POST['simpan'])) {
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $telepon = $_POST['telepon'];

    mysqli_query($koneksi, "INSERT INTO pelanggan (NamaPelanggan, Alamat, NomorTelepon)
    VALUES ('$nama', '$alamat', '$telepon')");

    header("Location: pelanggan.php");
    exit;
}

$data = mysqli_query($koneksi, "SELECT * FROM pelanggan");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Pelanggan</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="sidebar">
    <h2>KASIRKU</h2>
    <a href="dashboard.php">Dashboard</a>
    <a href="produk.php">Data Barang</a>
    <a href="pelanggan.php">Data Pelanggan</a>
    <a href="transaksi.php">Transaksi</a>
    <a href="logout.php">Logout</a>
</div>

<div class="content">
    <h2>Data Pelanggan</h2>

    <div class="isi">
        <h3>Tambah Pelanggan</h3>

        <form method="POST">
            <label>Nama Pelanggan</label>
            <input type="text" name="nama" placeholder="Nama pelanggan" required>

            <label>Alamat</label>
            <input type="text" name="alamat" placeholder="Alamat" required>

            <label>Nomor Telepon</label>
            <input type="text" name="telepon" placeholder="Nomor telepon" required>

            <button type="submit" name="simpan">Simpan</button>
        </form>
    </div>

    <div class="isi">
        <h3>Daftar Pelanggan</h3>

        <table border="1" cellpadding="10" width="100%">
            <tr>
                <th>No</th>
                <th>Nama Pelanggan</th>
                <th>Alamat</th>
                <th>Nomor Telepon</th>
            </tr>

            <?php
            $no = 1;
            while ($p = mysqli_fetch_assoc($data)) {
            ?>
            <tr>
                <td><?php echo $no++; ?></td>
                <td><?php echo htmlspecialchars($p['NamaPelanggan']); ?></td>
                <td><?php echo htmlspecialchars($p['Alamat']); ?></td>
                <td><?php echo htmlspecialchars($p['NomorTelepon']); ?></td>
            </tr>
            <?php } ?>
        </table>
    </div>
</div>

</body>
</html>
