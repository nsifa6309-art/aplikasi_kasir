
<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Kasirku</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<h2>APLIKASI KASIRKU</h2>

<h3>Selamat Datang, <?php echo $_SESSION['nama']; ?></h3>

<p>Level: <?php echo $_SESSION['role']; ?></p>

<a href="produk.php">Data Produk</a>
<br><br>

<a href="pelanggan.php">Data Pelanggan</a>
<br><br>

<a href="transaksi.php">Transaksi</a>
<br><br>

<a href="laporan.php">Laporan</a>
<br><br>

<a href="logout.php">Logout</a>

</body>
</html>
