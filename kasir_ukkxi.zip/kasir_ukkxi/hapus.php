if (isset($_POST['hapus'])) {

    $id = $_POST['id'];

    $hapus = mysqli_query($koneksi, "DELETE FROM produk WHERE ProdukID='$id'");

    if ($hapus) {
        echo "<script>
            alert('Barang berhasil dihapus');
            window.location='produk.php';
        </script>";
        exit;
    } else {
        echo "<script>alert('Barang tidak bisa dihapus karena sudah digunakan dalam transaksi');</script>";
    }
}