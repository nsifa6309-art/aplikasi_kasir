<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Kasirku</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="form">
    <h2>KASIRKU</h2>

    <h3>WELCOME,
    <?php echo htmlspecialchars($_SESSION['nama']); ?>
    </h3>

    <p>Anda berhasil login ke aplikasi Kasirku.</p>

    <a href="produk.php">Data Produk</a><br><br>
    <a href="transaksi.php">Transaksi</a><br><br>
    <a href="logout.php">Logout</a>
</div>

</body>
</html>