
<?php
session_start();
include "koneksi.php";

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit;
}

if (isset($_POST['tambah'])) {

    $nama = mysqli_real_escape_string($koneksi, $_POST['nama']);
    $harga = (int) $_POST['harga'];
    $stok = (int) $_POST['stok'];

    $simpan = mysqli_query($koneksi, "INSERT INTO produk
    (NamaProduk, Harga, Stok)
    VALUES ('$nama', '$harga', '$stok')");

    if ($simpan) {
        echo "<script>
            alert('Barang berhasil ditambahkan!');
            window.location='produk.php';
        </script>";
        exit;
    } else {
        echo "<script>
            alert('Barang gagal ditambahkan!');
            window.location='produk.php';
        </script>";
        exit;
    }
}

if (isset($_POST['hapus'])) {

    $id = (int) $_POST['id'];

    $cek = mysqli_query($koneksi, "
        SELECT * FROM detailpenjualan
        WHERE ProdukID='$id'
    ");

    if (!$cek) {
        die("Terjadi kesalahan: " . mysqli_error($koneksi));
    }

    if (mysqli_num_rows($cek) > 0) {

        echo "<script>
            alert('Barang tidak bisa dihapus karena sudah digunakan dalam transaksi!');
            window.location='produk.php';
        </script>";
        exit;

    } else {

        $hapus = mysqli_query($koneksi, "
            DELETE FROM produk
            WHERE ProdukID='$id'
        ");

        if ($hapus) {
            echo "<script>
                alert('Barang berhasil dihapus!');
                window.location='produk.php';
            </script>";
            exit;
        } else {
            echo "<script>
                alert('Barang gagal dihapus!');
                window.location='produk.php';
            </script>";
            exit;
        }
    }
}

$data = mysqli_query($koneksi, "
    SELECT * FROM produk
    ORDER BY ProdukID DESC
");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Barang</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="sidebar">
    <h2>KASIRKU</h2>

    <a href="dashboard.php">Dashboard</a>
    <a href="produk.php">Data Barang</a>
    <a href="transaksi.php">Transaksi</a>
    <a href="laporan.php">Laporan</a>
    <a href="logout.php">Logout</a>
</div>

<div class="content">

    <h2>Data Barang</h2>
    <p>Silakan tambahkan barang yang akan dijual.</p>

    <div class="isi">

        <h3>Tambah Barang</h3>

        <form method="POST">

            <input type="text" name="nama"
            placeholder="Nama Barang" required>

            <input type="number" name="harga"
            placeholder="Harga Barang" min="0" required>

            <input type="number" name="stok"
            placeholder="Jumlah Stok" min="0" required>

            <button type="submit" name="tambah">
                Simpan Barang
            </button>

        </form>

    </div>

    <div class="isi">

        <h3>Daftar Barang</h3>

        <table border="1" cellpadding="10"
        cellspacing="0" width="100%">

            <tr>
                <th>No</th>
                <th>Nama Barang</th>
                <th>Harga</th>
                <th>Stok</th>
                <th>Aksi</th>
            </tr>

            <?php
            $no = 1;

            while ($barang = mysqli_fetch_assoc($data)) {
            ?>

            <tr>

                <td><?php echo $no++; ?></td>

                <td>
                    <?php echo htmlspecialchars($barang['NamaProduk']); ?>
                </td>

                <td>
                    Rp <?php echo number_format($barang['Harga'], 0, ',', '.'); ?>
                </td>

                <td>
                    <?php echo $barang['Stok']; ?>
                </td>

                <td>

                    <a href="edit_produk.php?id=<?php echo $barang['ProdukID']; ?>">
                        Edit
                    </a>

                    <form method="POST"
                    style="display:inline;"
                    onsubmit="return confirm('Yakin ingin menghapus barang ini?');">

                        <input type="hidden" name="id"
                        value="<?php echo $barang['ProdukID']; ?>">

                        <button type="submit" name="hapus">
                            Hapus
                        </button>

                    </form>

                </td>

            </tr>

            <?php } ?>

        </table>

    </div>

</div>

</body>
</html>
