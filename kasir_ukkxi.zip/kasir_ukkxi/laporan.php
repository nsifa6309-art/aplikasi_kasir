
<?php
session_start();
include "koneksi.php";

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit;
}

// Mengambil jumlah transaksi dan total penjualan
$hasil = mysqli_query($koneksi, "
    SELECT COUNT(*) AS jumlah_transaksi,
    SUM(TotalHarga) AS total_penjualan
    FROM penjualan
");

$ringkasan = mysqli_fetch_assoc($hasil);

// Mengambil data laporan
$laporan = mysqli_query($koneksi, "
    SELECT
        penjualan.PenjualanID,
        penjualan.TanggalPenjualan,
        penjualan.TotalHarga,
        produk.NamaProduk,
        detailpenjualan.JumlahProduk,
        detailpenjualan.Subtotal
    FROM penjualan
    JOIN detailpenjualan
        ON penjualan.PenjualanID = detailpenjualan.PenjualanID
    JOIN produk
        ON detailpenjualan.ProdukID = produk.ProdukID
    ORDER BY penjualan.PenjualanID DESC
");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Laporan Kasirku</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="sidebar">
    <h2>KASIRKU</h2>

    <a href="dashboard.php">Dashboard</a>
    <a href="produk.php">Data Barang</a>
    <a href="transaksi.php">Transaksi</a>
    <a href="laporan.php">Laporan</a>
    <a href="logout.php">Logout</a>
</div>

<div class="content">

    <h2>Laporan Penjualan</h2>
    <p>Berikut adalah daftar transaksi yang sudah berhasil dilakukan.</p>

    <div class="laporan-box">

        <div class="kartu-laporan">
            <h3>Jumlah Transaksi</h3>
            <h2>
                <?php echo $ringkasan['jumlah_transaksi']; ?>
            </h2>
        </div>

        <div class="kartu-laporan">
            <h3>Total Penjualan</h3>
            <h2>
                Rp <?php echo number_format($ringkasan['total_penjualan'] ?? 0, 0, ',', '.'); ?>
            </h2>
        </div>

    </div>

    <div class="isi">

        <h3>Riwayat Penjualan</h3>

        <table border="1" cellpadding="10" cellspacing="0" width="100%">

            <tr>
                <th>No</th>
                <th>ID Transaksi</th>
                <th>Tanggal</th>
                <th>Nama Barang</th>
                <th>Jumlah</th>
                <th>Subtotal</th>
                <th>Total Harga</th>
            </tr>

            <?php
            $no = 1;

            if (mysqli_num_rows($laporan) > 0) {
                while ($r = mysqli_fetch_assoc($laporan)) {
            ?>

            <tr>
                <td><?php echo $no++; ?></td>

                <td>
                    <?php echo $r['PenjualanID']; ?>
                </td>

                <td>
                    <?php echo $r['TanggalPenjualan']; ?>
                </td>

                <td>
                    <?php echo htmlspecialchars($r['NamaProduk']); ?>
                </td>

                <td>
                    <?php echo $r['JumlahProduk']; ?>
                </td>

                <td>
                    Rp <?php echo number_format($r['Subtotal'], 0, ',', '.'); ?>
                </td>

                <td>
                    Rp <?php echo number_format($r['TotalHarga'], 0, ',', '.'); ?>
                </td>
            </tr>

            <?php
                }
            } else {
            ?>

            <tr>
                <td colspan="7" align="center">
                    Belum ada transaksi penjualan.
                </td>
            </tr>

            <?php } ?>

        </table>

        <br>

        <a href="transaksi.php" class="tombol-transaksi">
            + Transaksi Baru
        </a>

    </div>

</div>

</body>
</html>
