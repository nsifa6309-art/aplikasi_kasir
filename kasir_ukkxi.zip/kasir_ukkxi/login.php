<!DOCTYPE html>
<html>
<head>
    <title>Login Kasirku</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="form">
    <h2>LOGIN KASIRKU</h2>

    <form method="post" action="login_controller.php">

        <input type="text" name="username"
        placeholder="Username" required>

        <input text="password" name="password"
        placeholder="Password" required>

        <button type="submit" name="login">LOGIN</button>

    </form>

    <p>Belum punya akun?</p>
    <a href="register.php">Daftar di sini</a>
</div>

</body>
</html>
